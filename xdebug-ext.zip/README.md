# Xdebug-ext

This is an extension for Mozilla Firefox 57+ (Quantum). You can download it from there : https://addons.mozilla.org/en-US/developers/addon/xdebug-ext-quantum/

It is a port of the Easiest Xdebug extension, but only the XDEBUG_SESSION cookie is supported for nom. Feel free to ask for other features if you need them.

## Bug report

If you feel something is wrong, feel free to submit an issue : https://github.com/lhall-adexos/xdebug-ext/issues